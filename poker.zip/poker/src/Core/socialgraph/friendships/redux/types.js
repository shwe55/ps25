const IMFriendshipActionsConstants = {
  SET_FRIENDS: 'SET_FRIENDS',
  SET_FRIENDSHIPS: 'SET_FRIENDSHIPS',
  DID_SUBSCRIBE: 'DID_SUBSCRIBE',
};

export default IMFriendshipActionsConstants;
