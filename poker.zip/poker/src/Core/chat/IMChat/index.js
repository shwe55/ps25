export { default } from './IMChat';
