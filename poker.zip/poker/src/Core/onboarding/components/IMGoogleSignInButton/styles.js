import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  image: {
    width: 40,
    height: 40,
  },
});

export default styles;
