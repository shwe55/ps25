/*
* If this doesn't work with the current FB SDK used by the expo package, modify it manually in node_modules/expo-ads-facebook/android/build.gradle
* to

api 'com.facebook.android:audience-network-sdk:5.+'

*/
export { default as IMNativeFBAdComponentView } from './IMNativeFBAdComponentView';
