export { default as IMNotificationScreen } from './IMNotificationScreen/IMNotificationScreen';
export { notificationManager } from './firebase/notificationManager';

import * as firebaseNotification from './firebase/notification';
export { firebaseNotification };
