export { default } from './TNEmptyStateView';
