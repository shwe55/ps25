const IMUserReportingActionsConstants = {
  SET_BANNED_USER_IDS: 'SET_BANNED_USER_IDS',
};

export default IMUserReportingActionsConstants;
