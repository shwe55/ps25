import * as reportingManager from './firebase';
export { reportingManager };
