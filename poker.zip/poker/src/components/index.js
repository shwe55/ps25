export { default as Feed } from './screens/Feed/Feed';
export { default as DetailPost } from './screens/DetailPost/DetailPost';
export { default as CreatePost } from './screens/CreatePost/CreatePost';
export { default as Profile } from './screens/Profile/Profile';
