//
//  SwiftHeader.swift
//  SocialNetwork
//
//  Created by Florian Marcu on 9/9/20.
//  Copyright © 2020 Instamobile Code SRL. All rights reserved.
//

import UIKit

class SwiftHeader: NSObject {

}
