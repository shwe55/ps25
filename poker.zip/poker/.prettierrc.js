module.exports = {
  bracketSpacing: true,
  jsxBracketSameLine: true,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'all',
  semi: true,
};
